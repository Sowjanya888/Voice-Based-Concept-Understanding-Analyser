"""
report_page.py
----------------
Streamlit page for previewing session results and downloading a PDF report.
Relies on state populated by pages/main_page.py after an evaluation run.
"""

from __future__ import annotations

import os
import tempfile

import streamlit as st

from utils.visualization import plot_waveform
from utils.pdf_generator import generate_report


def render_report_page():
    st.title("📄 Evaluation Report")

    if not st.session_state.get("evaluated"):
        st.info("Run an evaluation on the Main page first, then come back here to generate a report.")
        return

    sim = st.session_state["similarity_result"]
    metrics = st.session_state["audio_metrics"]
    feedback = st.session_state.get("feedback", "")

    student_name = st.text_input("Student name (for the report header)", value="Student")

    st.subheader("Preview")
    st.write(f"**Concept:** {st.session_state['concept_name']}")
    st.write(f"**Semantic Accuracy:** {sim.similarity:.2f} ({sim.label})")
    st.write(f"**Delivery Score:** {metrics.delivery_score:.1f} / 100")
    st.write(f"**Feedback:** {feedback}")

    if st.button("Generate PDF report", type="primary"):
        with st.spinner("Rendering waveform image..."):
            waveform_png = tempfile.NamedTemporaryFile(delete=False, suffix=".png").name
            plot_waveform(st.session_state["audio_path"], save_path=waveform_png)

        with st.spinner("Assembling PDF..."):
            output_path = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf").name
            generate_report(
                output_path=output_path,
                engine="weasyprint",
                student_name=student_name,
                concept_description=st.session_state["concept_description"],
                transcript=st.session_state["transcript"],
                accuracy_score=sim.similarity,
                understanding_label=sim.label,
                filler_count=metrics.filler_count,
                pause_ratio=metrics.pause_ratio,
                delivery_score=metrics.delivery_score,
                feedback=feedback,
                waveform_image_path=waveform_png,
            )

        with open(output_path, "rb") as pdf_file:
            st.download_button(
                label="⬇️ Download PDF report",
                data=pdf_file.read(),
                file_name=f"VBCUA_report_{student_name.replace(' ', '_')}.pdf",
                mime="application/pdf",
            )
        st.success("Report generated.")


if __name__ == "__main__":
    render_report_page()
