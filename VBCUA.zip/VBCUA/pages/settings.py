"""
settings.py
------------
Optional settings / configuration page: API key check, STT backend choice,
and (if a database is wired up) a simple history view of past sessions.
"""

from __future__ import annotations

import os

import streamlit as st


def render_settings_page():
    st.title("⚙️ Settings")

    st.subheader("OpenAI API Key")
    key_present = bool(os.environ.get("OPENAI_API_KEY"))
    if key_present:
        st.success("OPENAI_API_KEY is set in the environment.")
    else:
        st.warning(
            "OPENAI_API_KEY is not set. Required if using the 'api' speech-to-text "
            "backend. Set it as an environment variable before launching the app, "
            "e.g. `export OPENAI_API_KEY=sk-...`"
        )

    st.subheader("Speech-to-Text Backend")
    st.write(
        "Choose the backend on the Main page sidebar:\n"
        "- **api**: OpenAI's hosted `whisper-1` model (fast, needs API key & internet).\n"
        "- **local**: Runs `openai-whisper` locally (needs `ffmpeg`, can use a GPU)."
    )

    st.subheader("Session History")
    st.caption(
        "Wire up app_core/database.py (SQLAlchemy models for User, Session, "
        "AudioRecording, Concept, Evaluation) to persist and list past sessions here."
    )


if __name__ == "__main__":
    render_settings_page()
