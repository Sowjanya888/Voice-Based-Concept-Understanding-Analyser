"""
main_page.py
-------------
Primary Streamlit UI: pick a concept, upload/record an answer, run the
STT -> semantic scoring -> audio scoring pipeline, and show results.
"""

from __future__ import annotations

import os
import tempfile

import streamlit as st

from app_core.speech_to_text import Transcriber, count_filler_words
from app_core.semantic_engine import SemanticEngine
from app_core.audio_scoring import analyze_audio
from utils.visualization import plot_waveform


# --- Sample concept bank (swap for database.py-backed storage in production) ---
SAMPLE_CONCEPTS = {
    "Gravity": "Gravity is the force of attraction between any two masses; it causes objects "
    "to fall toward the Earth and keeps planets in orbit around the sun.",
    "Photosynthesis": "Photosynthesis is the process by which plants convert light energy, "
    "water, and carbon dioxide into glucose and oxygen.",
    "Newton's First Law": "An object at rest stays at rest, and an object in motion stays in "
    "motion at constant velocity, unless acted on by a net external force.",
}


def _get_transcriber() -> Transcriber:
    if "transcriber" not in st.session_state:
        backend = st.session_state.get("stt_backend", "api")
        st.session_state["transcriber"] = Transcriber(backend=backend)
    return st.session_state["transcriber"]


def _get_semantic_engine() -> SemanticEngine:
    if "semantic_engine" not in st.session_state:
        st.session_state["semantic_engine"] = SemanticEngine()
    return st.session_state["semantic_engine"]


def render_main_page():
    st.title("🎤 VBCUA: Concept Understanding Analyzer")
    st.caption("Explain a concept out loud and get instant, objective feedback.")

    with st.sidebar:
        st.header("Controls")
        concept_name = st.selectbox("Choose a concept", list(SAMPLE_CONCEPTS.keys()))
        st.session_state["stt_backend"] = st.radio(
            "Speech-to-text backend", options=["api", "local"], index=0,
            help="'api' uses OpenAI's hosted Whisper endpoint (needs OPENAI_API_KEY). "
                 "'local' runs openai-whisper on this machine (needs ffmpeg).",
        )
        st.divider()
        st.caption("VBCUA automates routine grading — it assists, not replaces, instructor judgment.")

    reference_answer = SAMPLE_CONCEPTS[concept_name]
    with st.expander("Show expected explanation (for reference)"):
        st.write(reference_answer)

    st.subheader("1. Provide your spoken explanation")
    uploaded_audio = st.file_uploader(
        "Upload an audio recording (WAV/MP3/M4A)", type=["wav", "mp3", "m4a"]
    )

    if uploaded_audio is None:
        st.info("Upload a recording of yourself explaining the concept to begin.")
        return

    # Persist the upload to a temp file so downstream libraries can open it by path.
    suffix = os.path.splitext(uploaded_audio.name)[1] or ".wav"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
        tmp_file.write(uploaded_audio.read())
        audio_path = tmp_file.name

    st.audio(uploaded_audio)

    if st.button("Evaluate my explanation", type="primary"):
        with st.spinner("Transcribing audio..."):
            try:
                transcriber = _get_transcriber()
                transcription = transcriber.transcribe(audio_path)
                st.session_state["transcript"] = transcription.text
            except Exception as exc:  # noqa: BLE001
                st.error(f"Transcription failed: {exc}")
                return

        with st.spinner("Scoring semantic understanding..."):
            engine = _get_semantic_engine()
            similarity_result = engine.score(st.session_state["transcript"], reference_answer)

        with st.spinner("Analyzing delivery (pauses, energy, fillers)..."):
            filler_count = count_filler_words(st.session_state["transcript"])
            audio_metrics = analyze_audio(
                audio_path, transcript=st.session_state["transcript"], filler_count=filler_count
            )

        # Stash everything needed by the report page.
        st.session_state["audio_path"] = audio_path
        st.session_state["concept_name"] = concept_name
        st.session_state["concept_description"] = reference_answer
        st.session_state["similarity_result"] = similarity_result
        st.session_state["audio_metrics"] = audio_metrics
        st.session_state["evaluated"] = True

    if st.session_state.get("evaluated"):
        _render_results(reference_answer)


def _render_results(reference_answer: str):
    st.subheader("2. Transcript")
    st.write(st.session_state["transcript"])

    st.subheader("3. Waveform")
    fig = plot_waveform(st.session_state["audio_path"])
    st.pyplot(fig)

    st.subheader("4. Results")
    sim = st.session_state["similarity_result"]
    metrics = st.session_state["audio_metrics"]

    col1, col2, col3 = st.columns(3)
    col1.metric("Semantic Accuracy", f"{sim.similarity:.2f}")
    col2.metric("Delivery Score", f"{metrics.delivery_score:.1f} / 100")
    col3.metric("Pause Ratio", f"{metrics.pause_ratio:.1%}")

    st.table(
        {
            "Metric": [
                "Understanding Level",
                "Filler Word Count",
                "Speaking Rate (words/sec)",
                "Audio Duration (s)",
            ],
            "Value": [
                sim.label,
                metrics.filler_count,
                metrics.speaking_rate_wps if metrics.speaking_rate_wps is not None else "N/A",
                metrics.duration_seconds,
            ],
        }
    )

    feedback = _build_feedback(sim.label, metrics)
    st.session_state["feedback"] = feedback

    if sim.label == "Strong":
        st.success(feedback)
    elif sim.label == "Moderate":
        st.warning(feedback)
    else:
        st.error(feedback)

    st.caption("Go to the **Report** page in the sidebar to download a PDF summary.")


def _build_feedback(label: str, metrics) -> str:
    parts = []
    if label == "Strong":
        parts.append("Strong understanding! Your explanation closely matches the expected concept.")
    elif label == "Moderate":
        parts.append("Moderate understanding. Some key ideas are present, but the explanation could be more precise.")
    else:
        parts.append("Your explanation doesn't yet capture the core concept — consider reviewing the material and trying again.")

    if metrics.pause_ratio > 0.35:
        parts.append("You paused for a large portion of the recording — try to speak more continuously.")
    if metrics.filler_count > 3:
        parts.append(f"You used {metrics.filler_count} filler words (e.g. 'um', 'like') — reducing these will make your explanation clearer.")

    return " ".join(parts)


if __name__ == "__main__":
    render_main_page()
