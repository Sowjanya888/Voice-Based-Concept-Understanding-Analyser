# VBCUA — Voice-Based Concept Understanding Analyzer

VBCUA lets a student speak an explanation of a concept out loud and gives
instant, objective feedback: how semantically accurate the explanation is
(via speech-to-text + SBERT similarity) and how well it was delivered
(pauses, filler words, speaking rate, signal energy). It's built as an
instructor's assistant — it automates routine grading and surfaces areas
for improvement, without replacing human judgment.

## Features

- 🎙️ **Speech-to-text** via OpenAI Whisper (hosted API or local model)
- 🧠 **Semantic scoring** via Sentence-Transformers (SBERT) cosine similarity
- 📊 **Delivery metrics**: pause ratio, filler word count, speaking rate, RMS energy
- 🖥️ **Streamlit UI** with waveform visualization and a metrics table
- 📄 **PDF report generation** (WeasyPrint, with a ReportLab fallback)
- 🗄️ Optional **SQLite/SQLAlchemy** persistence of sessions and evaluations
- 🐳 **Docker**-ready for deployment

## Data Model (ER Diagram)

```
User (id, name, email)
  └──< Session (id, user_id, concept_id, timestamp) >── Concept (id, description, expected_response)
             │
             ├── AudioRecording (id, session_id, file_path, transcript)   [1:1]
             └── Evaluation (id, session_id, accuracy_score, filler_count,
                              pause_ratio, delivery_score, feedback)        [1:1]
```

- A **User** has many **Sessions** (one per concept they attempt).
- Each **Session** links exactly one **Concept**, one **AudioRecording**,
  and one **Evaluation**.
- See `app_core/database.py` for the SQLAlchemy ORM implementation of this
  schema.

## Project Structure

```
VBCUA/
├── app_core/                # Backend logic (no Streamlit imports here)
│   ├── speech_to_text.py    # Whisper transcription (API + local)
│   ├── semantic_engine.py   # SBERT embeddings & similarity scoring
│   ├── audio_scoring.py     # Pause/energy/filler/delivery metrics
│   └── database.py          # SQLAlchemy models + helpers
├── pages/                   # Streamlit UI pages
│   ├── main_page.py         # Record/upload + run the evaluation pipeline
│   ├── report_page.py       # Preview + download the PDF report
│   └── settings.py          # API key check, backend choice, history
├── utils/
│   ├── visualization.py     # Waveform & metrics plots (matplotlib/librosa)
│   └── pdf_generator.py     # HTML->PDF (WeasyPrint) / ReportLab report builder
├── tests/                   # pytest unit tests for each module
├── data/
│   ├── audio/                # (gitignored) uploaded/recorded audio
│   └── reports/               # (gitignored) generated PDF reports
├── main.py                  # Streamlit entry point (`streamlit run main.py`)
├── requirements.txt
├── Dockerfile
├── .streamlit/config.toml   # Theme + server config
├── .env.example
└── README.md
```

## Setup

### 1. Environment

Requires Python 3.10+ and `ffmpeg` on your PATH (needed by the local
Whisper backend).

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

`ffmpeg` install (if you don't already have it):

```bash
# macOS
brew install ffmpeg
# Ubuntu/Debian
sudo apt-get install ffmpeg
```

### 2. Configure your API key

Only needed if you use the "api" speech-to-text backend (default):

```bash
cp .env.example .env
# then edit .env and set OPENAI_API_KEY=sk-...
export OPENAI_API_KEY=sk-...        # or use a tool like `direnv`/`python-dotenv`
```

If you'd rather not use the API, choose the "local" backend in the app
sidebar — it runs `openai-whisper` on your machine and needs no API key
(but is slower on CPU).

### 3. Run the app

```bash
streamlit run main.py
```

Then open the URL Streamlit prints (default `http://localhost:8501`).

### 4. Run tests

```bash
pytest
```

Note: `test_semantic_engine.py` downloads the `all-MiniLM-L6-v2` model on
first run and needs internet access; `test_audio_scoring.py` and
`test_database.py` are fully offline.

## Docker

```bash
docker build -t vbcua .
docker run -p 8501:8501 -e OPENAI_API_KEY=sk-... vbcua
```

Then visit `http://localhost:8501`.

## How scoring works

1. **Transcription** — the uploaded/recorded audio is sent to Whisper
   (API or local) to produce a text transcript.
2. **Semantic accuracy** — the transcript and the concept's reference
   answer are embedded with SBERT (`all-MiniLM-L6-v2` by default) and
   compared via cosine similarity. Thresholds (configurable in
   `semantic_engine.py`) classify the result as **Strong / Moderate / Poor**.
3. **Delivery quality** — `librosa` detects silence to compute a pause
   ratio, RMS energy indicates loudness/consistency, and a simple filler-word
   heuristic counts disfluencies in the transcript. These combine into a
   0–100 **delivery score** (see `compute_delivery_score` in
   `audio_scoring.py` — the weights are intentionally simple and meant to be
   recalibrated against real classroom data).
4. **Feedback** — plain-language feedback is generated from both scores and
   shown in the UI; a full PDF report (transcript, metrics table, waveform,
   feedback) can be downloaded from the Report page.

## Extending

- **Persistence**: `app_core/database.py` already defines the full ER
  schema. Wire `create_session_with_results(...)` into `main_page.py` after
  an evaluation to persist history, and build a "Session History" view in
  `settings.py` or a new `pages/dashboard.py`.
- **Better filler detection**: the current approach counts filler words in
  the *transcript*, but Whisper often smooths over disfluencies. For higher
  accuracy, consider acoustic-level disfluency detection instead.
- **Performance**: swap in [faster-whisper](https://github.com/SYSTRAN/faster-whisper)
  (CTranslate2-based, up to ~4x faster) for local transcription, and use
  FP16 SBERT on GPU for faster embedding.
- **Multilingual support**: Whisper auto-detects language; pass a
  `language` hint to `Transcriber.transcribe()` to force a specific one, and
  make sure your reference answers/SBERT model support that language.

## Disclaimer

VBCUA provides automated, reproducible feedback to assist instructors and
learners. It is not a substitute for human grading or pedagogical judgment,
especially for nuanced or partially-correct explanations.
