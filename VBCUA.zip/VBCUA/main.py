"""
main.py
--------
VBCUA Streamlit entry point. Run with:

    streamlit run main.py
"""

import streamlit as st

from pages.main_page import render_main_page
from pages.report_page import render_report_page
from pages.settings import render_settings_page

st.set_page_config(page_title="VBCUA", page_icon="🎤", layout="wide")


def init_session_state():
    defaults = {
        "evaluated": False,
        "transcript": "",
        "stt_backend": "api",
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def main():
    init_session_state()

    page = st.sidebar.radio("Navigate", ["Main", "Report", "Settings"], index=0)

    if page == "Main":
        render_main_page()
    elif page == "Report":
        render_report_page()
    else:
        render_settings_page()


if __name__ == "__main__":
    main()
