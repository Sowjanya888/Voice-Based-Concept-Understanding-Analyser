"""
speech_to_text.py
------------------
Transcribes audio recordings into text using OpenAI Whisper.

Supports two backends:
  1. "api"   - OpenAI's hosted Whisper endpoint (whisper-1). Requires
               OPENAI_API_KEY to be set as an environment variable.
  2. "local" - The open-source `openai-whisper` package, run locally.
               Requires `pip install -U openai-whisper` and the `ffmpeg`
               binary to be available on the system PATH.

Usage:
    from app_core.speech_to_text import Transcriber

    transcriber = Transcriber(backend="api")
    result = transcriber.transcribe("data/audio/response.wav")
    print(result.text)
"""

from __future__ import annotations

import os
import logging
from dataclasses import dataclass, field
from typing import Optional, List

logger = logging.getLogger(__name__)


@dataclass
class TranscriptionResult:
    """Container for a transcription and any metadata Whisper returns."""

    text: str
    language: Optional[str] = None
    duration: Optional[float] = None
    segments: List[dict] = field(default_factory=list)


class TranscriptionError(RuntimeError):
    """Raised when a transcription attempt fails."""


class Transcriber:
    """Wraps either the OpenAI Whisper API or the local whisper package."""

    def __init__(self, backend: str = "api", model_size: str = "base"):
        """
        Args:
            backend: "api" to use OpenAI's hosted whisper-1 model, or
                     "local" to run an open-source whisper model on-device.
            model_size: Only used when backend="local". One of
                        tiny/base/small/medium/large.
        """
        if backend not in ("api", "local"):
            raise ValueError("backend must be 'api' or 'local'")

        self.backend = backend
        self.model_size = model_size
        self._client = None
        self._local_model = None

        if backend == "api":
            self._init_api_client()
        else:
            self._init_local_model()

    def _init_api_client(self) -> None:
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise ImportError(
                "The 'openai' package is required for backend='api'. "
                "Install it with: pip install openai"
            ) from exc

        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            logger.warning(
                "OPENAI_API_KEY not found in environment. "
                "Set it before calling transcribe()."
            )
        self._client = OpenAI(api_key=api_key)

    def _init_local_model(self) -> None:
        try:
            import whisper
        except ImportError as exc:
            raise ImportError(
                "The 'openai-whisper' package is required for backend='local'. "
                "Install it with: pip install -U openai-whisper "
                "(and make sure ffmpeg is installed)."
            ) from exc

        logger.info("Loading local Whisper model '%s'...", self.model_size)
        self._local_model = whisper.load_model(self.model_size)

    def transcribe(self, audio_path: str, language: Optional[str] = None) -> TranscriptionResult:
        """Transcribe an audio file and return a TranscriptionResult.

        Args:
            audio_path: Path to a WAV/MP3/M4A audio file.
            language: Optional ISO language hint (e.g. "en"). If omitted,
                      Whisper will auto-detect the language.
        """
        if not os.path.exists(audio_path):
            raise FileNotFoundError(f"Audio file not found: {audio_path}")

        if self.backend == "api":
            return self._transcribe_api(audio_path, language)
        return self._transcribe_local(audio_path, language)

    def _transcribe_api(self, audio_path: str, language: Optional[str]) -> TranscriptionResult:
        try:
            with open(audio_path, "rb") as audio_file:
                kwargs = {"model": "whisper-1", "file": audio_file}
                if language:
                    kwargs["language"] = language
                transcription = self._client.audio.transcriptions.create(**kwargs)
        except Exception as exc:  # noqa: BLE001 - surface as our own error type
            raise TranscriptionError(f"Whisper API transcription failed: {exc}") from exc

        return TranscriptionResult(text=transcription.text.strip())

    def _transcribe_local(self, audio_path: str, language: Optional[str]) -> TranscriptionResult:
        try:
            options = {}
            if language:
                options["language"] = language
            result = self._local_model.transcribe(audio_path, **options)
        except Exception as exc:  # noqa: BLE001
            raise TranscriptionError(f"Local Whisper transcription failed: {exc}") from exc

        return TranscriptionResult(
            text=result.get("text", "").strip(),
            language=result.get("language"),
            segments=result.get("segments", []),
        )


def count_filler_words(transcript: str, filler_terms: Optional[List[str]] = None) -> int:
    """Count occurrences of common filler words/phrases in a transcript.

    Note: Whisper often smooths over disfluencies, so this is a best-effort
    heuristic on the returned text, not a substitute for acoustic disfluency
    detection.
    """
    if filler_terms is None:
        filler_terms = ["um", "uh", "uhh", "umm", "like", "you know", "i mean", "sort of", "kind of"]

    lowered = f" {transcript.lower()} "
    count = 0
    for term in filler_terms:
        count += lowered.count(f" {term} ")
    return count
