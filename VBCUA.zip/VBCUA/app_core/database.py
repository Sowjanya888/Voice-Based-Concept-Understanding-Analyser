"""
database.py
------------
ORM models and helper functions implementing the VBCUA ER diagram:

    User (1) ----< Session (M) >---- Concept (1)
                       |
                       | (1:1)
                       v
                 AudioRecording
                       |
                       | (1:1)
                       v
                  Evaluation

Entities:
    User            - a student using the system.
    Concept         - a target concept with an expected/reference explanation.
    Session         - one instance of a user answering a concept.
    AudioRecording  - the recorded explanation + transcript for a session.
    Evaluation      - computed metrics + qualitative feedback for a session.

Uses SQLAlchemy ORM with SQLite by default (swap the connection string in
get_engine() for Postgres/MySQL in production).
"""

from __future__ import annotations

import datetime as dt
from typing import Optional

from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    Float,
    String,
    Text,
    DateTime,
    ForeignKey,
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker, Session as OrmSession

Base = declarative_base()


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, nullable=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    sessions = relationship("Session", back_populates="user", cascade="all, delete-orphan")


class Concept(Base):
    __tablename__ = "concepts"

    id = Column(Integer, primary_key=True)
    description = Column(Text, nullable=False)
    expected_response = Column(Text, nullable=False)

    sessions = relationship("Session", back_populates="concept")


class Session(Base):
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    concept_id = Column(Integer, ForeignKey("concepts.id"), nullable=False)
    timestamp = Column(DateTime, default=dt.datetime.utcnow)

    user = relationship("User", back_populates="sessions")
    concept = relationship("Concept", back_populates="sessions")
    audio_recording = relationship(
        "AudioRecording", back_populates="session", uselist=False, cascade="all, delete-orphan"
    )
    evaluation = relationship(
        "Evaluation", back_populates="session", uselist=False, cascade="all, delete-orphan"
    )


class AudioRecording(Base):
    __tablename__ = "audio_recordings"

    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False, unique=True)
    file_path = Column(String(500), nullable=False)
    transcript = Column(Text, nullable=True)

    session = relationship("Session", back_populates="audio_recording")


class Evaluation(Base):
    __tablename__ = "evaluations"

    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False, unique=True)
    accuracy_score = Column(Float, nullable=True)     # semantic similarity, 0-1
    filler_count = Column(Integer, default=0)
    pause_ratio = Column(Float, nullable=True)         # 0-1
    delivery_score = Column(Float, nullable=True)      # 0-100
    feedback = Column(Text, nullable=True)

    session = relationship("Session", back_populates="evaluation")


def get_engine(db_url: str = "sqlite:///vbcua.db"):
    return create_engine(db_url, echo=False, future=True)


def init_db(engine=None):
    """Create all tables. Safe to call repeatedly (no-op if tables exist)."""
    engine = engine or get_engine()
    Base.metadata.create_all(engine)
    return engine


def get_session_factory(engine=None):
    engine = engine or init_db()
    return sessionmaker(bind=engine, future=True)


# --- Convenience helpers -----------------------------------------------

def get_or_create_user(db: OrmSession, name: str, email: Optional[str] = None) -> User:
    user = db.query(User).filter_by(name=name).first()
    if user:
        return user
    user = User(name=name, email=email)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def create_concept(db: OrmSession, description: str, expected_response: str) -> Concept:
    concept = Concept(description=description, expected_response=expected_response)
    db.add(concept)
    db.commit()
    db.refresh(concept)
    return concept


def create_session_with_results(
    db: OrmSession,
    user: User,
    concept: Concept,
    audio_file_path: str,
    transcript: str,
    accuracy_score: float,
    filler_count: int,
    pause_ratio: float,
    delivery_score: float,
    feedback: str,
) -> Session:
    """Persist a full evaluation round (session + recording + evaluation)."""
    session = Session(user=user, concept=concept)
    db.add(session)
    db.flush()  # assigns session.id without committing yet

    recording = AudioRecording(
        session_id=session.id,
        file_path=audio_file_path,
        transcript=transcript,
    )
    evaluation = Evaluation(
        session_id=session.id,
        accuracy_score=accuracy_score,
        filler_count=filler_count,
        pause_ratio=pause_ratio,
        delivery_score=delivery_score,
        feedback=feedback,
    )

    db.add_all([recording, evaluation])
    db.commit()
    db.refresh(session)
    return session
