"""
audio_scoring.py
------------------
Extracts delivery-quality metrics from an audio recording:
  - Pause ratio (silence detection via librosa)
  - RMS signal energy (loudness / consistency)
  - Speaking rate (words per second, given a transcript + audio duration)
  - Filler word count (delegated to speech_to_text.count_filler_words)

These metrics are combined into a single "delivery score" that can be
shown alongside the semantic accuracy score from semantic_engine.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class AudioMetrics:
    duration_seconds: float
    pause_ratio: float          # fraction of audio classified as silence, [0, 1]
    rms_energy_mean: float      # average RMS energy across the clip
    rms_energy_std: float       # variability of RMS energy
    speaking_rate_wps: Optional[float]  # words per second, if word_count given
    filler_count: int
    delivery_score: float       # composite 0-100 score


def load_audio(audio_path: str, sr: Optional[int] = None):
    """Load an audio file as a mono waveform using librosa.

    Returns (waveform, sample_rate).
    """
    import librosa

    waveform, sample_rate = librosa.load(audio_path, sr=sr, mono=True)
    return waveform, sample_rate


def compute_pause_ratio(waveform: np.ndarray, sample_rate: int, top_db: int = 30) -> float:
    """Estimate the fraction of the clip that is silence.

    Uses librosa.effects.split to find non-silent intervals; anything not
    covered by those intervals is treated as a pause.
    """
    import librosa

    if len(waveform) == 0:
        return 0.0

    non_silent_intervals = librosa.effects.split(waveform, top_db=top_db)
    non_silent_samples = sum(end - start for start, end in non_silent_intervals)
    total_samples = len(waveform)

    if total_samples == 0:
        return 0.0

    silent_samples = max(total_samples - non_silent_samples, 0)
    return float(silent_samples / total_samples)


def compute_rms_energy(waveform: np.ndarray):
    """Return (mean, std) of the RMS energy across the clip."""
    import librosa

    if len(waveform) == 0:
        return 0.0, 0.0

    rms = librosa.feature.rms(y=waveform)[0]
    return float(np.mean(rms)), float(np.std(rms))


def compute_speaking_rate(word_count: int, duration_seconds: float) -> Optional[float]:
    """Words per second. Returns None if duration is zero/unknown."""
    if not duration_seconds or duration_seconds <= 0:
        return None
    return round(word_count / duration_seconds, 3)


def compute_delivery_score(
    pause_ratio: float,
    filler_count: int,
    word_count: int,
    rms_energy_std: float,
) -> float:
    """Combine sub-metrics into a single 0-100 "delivery" score.

    This is a simple, tunable heuristic:
      - Start at 100.
      - Subtract for excessive pausing (target < ~20% silence).
      - Subtract for filler words, scaled by how many words were spoken.
      - Subtract a little for very inconsistent energy (choppy delivery).
    Feel free to recalibrate the weights against real classroom data.
    """
    score = 100.0

    # Penalize pause ratio above a reasonable baseline (~20%).
    excess_pause = max(pause_ratio - 0.20, 0.0)
    score -= excess_pause * 100 * 0.8

    # Penalize filler words relative to total words spoken.
    if word_count > 0:
        filler_rate = filler_count / word_count
        score -= filler_rate * 100 * 0.6
    elif filler_count > 0:
        score -= 15

    # Mild penalty for very jumpy energy (rough proxy for erratic delivery).
    score -= min(rms_energy_std * 50, 10)

    return float(max(0.0, min(100.0, round(score, 1))))


def analyze_audio(
    audio_path: str,
    transcript: str = "",
    filler_count: Optional[int] = None,
) -> AudioMetrics:
    """Run the full audio-scoring pipeline on a single recording.

    Args:
        audio_path: Path to the audio file.
        transcript: The transcribed text (used for word count / speaking rate).
        filler_count: Precomputed filler word count. If None, it will be
                      derived from the transcript using a simple heuristic.
    """
    from app_core.speech_to_text import count_filler_words

    waveform, sample_rate = load_audio(audio_path)
    duration = float(len(waveform) / sample_rate) if sample_rate else 0.0

    pause_ratio = compute_pause_ratio(waveform, sample_rate)
    rms_mean, rms_std = compute_rms_energy(waveform)

    word_count = len(transcript.split()) if transcript else 0
    speaking_rate = compute_speaking_rate(word_count, duration)

    if filler_count is None:
        filler_count = count_filler_words(transcript) if transcript else 0

    delivery_score = compute_delivery_score(
        pause_ratio=pause_ratio,
        filler_count=filler_count,
        word_count=word_count,
        rms_energy_std=rms_std,
    )

    return AudioMetrics(
        duration_seconds=round(duration, 2),
        pause_ratio=round(pause_ratio, 4),
        rms_energy_mean=round(rms_mean, 5),
        rms_energy_std=round(rms_std, 5),
        speaking_rate_wps=speaking_rate,
        filler_count=filler_count,
        delivery_score=delivery_score,
    )
