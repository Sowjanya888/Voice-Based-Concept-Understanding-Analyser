"""
semantic_engine.py
-------------------
Computes semantic similarity between a student's spoken explanation
(transcript) and a reference/expected answer for a given concept, using
Sentence-Transformers (SBERT) embeddings and cosine similarity.

Usage:
    from app_core.semantic_engine import SemanticEngine

    engine = SemanticEngine()
    result = engine.score("Gravity pulls objects toward each other.",
                           "Gravity is the force of attraction between masses.")
    print(result.similarity, result.label)
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Optional


@dataclass
class SimilarityResult:
    similarity: float          # cosine similarity, range [-1, 1] (practically [0, 1])
    label: str                 # "Strong" / "Moderate" / "Poor"


# Default thresholds for classifying understanding based on cosine similarity.
DEFAULT_STRONG_THRESHOLD = 0.75
DEFAULT_MODERATE_THRESHOLD = 0.50


class SemanticEngine:
    """Loads an SBERT model once and reuses it for repeated scoring calls."""

    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        strong_threshold: float = DEFAULT_STRONG_THRESHOLD,
        moderate_threshold: float = DEFAULT_MODERATE_THRESHOLD,
    ):
        self.model_name = model_name
        self.strong_threshold = strong_threshold
        self.moderate_threshold = moderate_threshold
        self._model = self._load_model(model_name)

    @staticmethod
    @lru_cache(maxsize=4)
    def _load_model(model_name: str):
        from sentence_transformers import SentenceTransformer

        return SentenceTransformer(model_name)

    def embed(self, text: str):
        """Return the embedding vector for a single string."""
        return self._model.encode([text])[0]

    def similarity(self, text_a: str, text_b: str) -> float:
        """Return cosine similarity between two strings, in [0, 1] typically."""
        from sentence_transformers import util

        emb_a = self._model.encode([text_a])
        emb_b = self._model.encode([text_b])
        sim = util.cos_sim(emb_a, emb_b)
        return float(sim[0][0])

    def classify(self, similarity: float) -> str:
        if similarity >= self.strong_threshold:
            return "Strong"
        if similarity >= self.moderate_threshold:
            return "Moderate"
        return "Poor"

    def score(self, student_answer: str, reference_answer: str) -> SimilarityResult:
        """Compute similarity and a qualitative label in one call."""
        if not student_answer or not student_answer.strip():
            return SimilarityResult(similarity=0.0, label="Poor")

        sim = self.similarity(student_answer, reference_answer)
        label = self.classify(sim)
        return SimilarityResult(similarity=round(sim, 4), label=label)
