"""
Unit tests for app_core/semantic_engine.py.

Run with: pytest tests/test_semantic_engine.py
Requires sentence-transformers + torch to be installed; these tests will
download the 'all-MiniLM-L6-v2' model on first run (needs internet access).
"""

import pytest

from app_core.semantic_engine import SemanticEngine


@pytest.fixture(scope="module")
def engine():
    return SemanticEngine()


def test_identical_sentences_score_near_one(engine):
    text = "Gravity is the force of attraction between two masses."
    result = engine.score(text, text)
    assert result.similarity > 0.95
    assert result.label == "Strong"


def test_unrelated_sentences_score_low(engine):
    student = "I like to eat pizza on Fridays."
    reference = "Gravity is the force of attraction between two masses."
    result = engine.score(student, reference)
    assert result.similarity < 0.5
    assert result.label in ("Poor", "Moderate")


def test_empty_answer_is_poor(engine):
    result = engine.score("", "Gravity is the force of attraction between two masses.")
    assert result.similarity == 0.0
    assert result.label == "Poor"


def test_classify_thresholds(engine):
    assert engine.classify(0.9) == "Strong"
    assert engine.classify(0.6) == "Moderate"
    assert engine.classify(0.1) == "Poor"
