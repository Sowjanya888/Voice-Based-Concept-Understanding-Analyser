"""
Unit tests for app_core/audio_scoring.py.

Uses synthetically generated audio (silence and a pure tone) so tests don't
depend on any external sample files.

Run with: pytest tests/test_audio_scoring.py
"""

import numpy as np
import soundfile as sf
import pytest

from app_core.audio_scoring import (
    compute_pause_ratio,
    compute_rms_energy,
    compute_speaking_rate,
    compute_delivery_score,
)


SAMPLE_RATE = 16000


@pytest.fixture
def silence_waveform():
    return np.zeros(SAMPLE_RATE * 2, dtype=np.float32)  # 2s of silence


@pytest.fixture
def tone_waveform():
    t = np.linspace(0, 2, SAMPLE_RATE * 2, endpoint=False)
    return (0.5 * np.sin(2 * np.pi * 440 * t)).astype(np.float32)  # 2s of 440Hz tone


def test_pure_silence_has_full_pause_ratio(silence_waveform):
    ratio = compute_pause_ratio(silence_waveform, SAMPLE_RATE)
    assert ratio == pytest.approx(1.0, abs=0.05)


def test_pure_tone_has_low_pause_ratio(tone_waveform):
    ratio = compute_pause_ratio(tone_waveform, SAMPLE_RATE)
    assert ratio < 0.3


def test_rms_energy_silence_is_near_zero(silence_waveform):
    mean, std = compute_rms_energy(silence_waveform)
    assert mean == pytest.approx(0.0, abs=1e-4)


def test_rms_energy_tone_is_positive(tone_waveform):
    mean, std = compute_rms_energy(tone_waveform)
    assert mean > 0.0


def test_speaking_rate_basic():
    assert compute_speaking_rate(word_count=10, duration_seconds=5.0) == 2.0
    assert compute_speaking_rate(word_count=10, duration_seconds=0.0) is None


def test_delivery_score_perfect_conditions():
    score = compute_delivery_score(
        pause_ratio=0.1, filler_count=0, word_count=50, rms_energy_std=0.01
    )
    assert score > 90


def test_delivery_score_poor_conditions():
    score = compute_delivery_score(
        pause_ratio=0.7, filler_count=15, word_count=30, rms_energy_std=0.5
    )
    assert score < 50
