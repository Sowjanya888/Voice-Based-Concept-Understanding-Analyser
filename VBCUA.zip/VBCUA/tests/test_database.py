"""
Unit tests for app_core/database.py using an in-memory SQLite database.

Run with: pytest tests/test_database.py
"""

import pytest

from app_core.database import (
    get_engine,
    init_db,
    get_session_factory,
    get_or_create_user,
    create_concept,
    create_session_with_results,
)


@pytest.fixture
def db():
    engine = get_engine("sqlite:///:memory:")
    init_db(engine)
    SessionFactory = get_session_factory(engine)
    session = SessionFactory()
    yield session
    session.close()


def test_get_or_create_user_is_idempotent(db):
    user1 = get_or_create_user(db, name="Alice", email="alice@example.com")
    user2 = get_or_create_user(db, name="Alice")
    assert user1.id == user2.id


def test_create_concept(db):
    concept = create_concept(db, description="Gravity", expected_response="Force between masses.")
    assert concept.id is not None
    assert concept.description == "Gravity"


def test_create_session_with_results_links_all_entities(db):
    user = get_or_create_user(db, name="Bob")
    concept = create_concept(db, description="Photosynthesis", expected_response="Plants making food.")

    session = create_session_with_results(
        db,
        user=user,
        concept=concept,
        audio_file_path="/tmp/fake.wav",
        transcript="Plants use sunlight to make food.",
        accuracy_score=0.82,
        filler_count=1,
        pause_ratio=0.15,
        delivery_score=88.5,
        feedback="Strong understanding!",
    )

    assert session.id is not None
    assert session.audio_recording.transcript == "Plants use sunlight to make food."
    assert session.evaluation.accuracy_score == 0.82
    assert session.user.name == "Bob"
    assert session.concept.description == "Photosynthesis"
