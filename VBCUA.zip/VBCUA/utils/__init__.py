"""Utility helpers for VBCUA (visualization, PDF generation)."""
