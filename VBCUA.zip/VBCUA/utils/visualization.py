"""
visualization.py
------------------
Helpers to render a waveform plot and a metrics chart for a session,
for use both in the Streamlit UI (st.pyplot) and in PDF report generation
(saved as PNG and embedded).
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import matplotlib

matplotlib.use("Agg")  # safe for headless / server-side rendering
import matplotlib.pyplot as plt


def plot_waveform(audio_path: str, save_path: Optional[str] = None):
    """Plot the waveform of an audio file.

    Returns the matplotlib Figure. If save_path is given, also saves a PNG.
    """
    import librosa
    import librosa.display

    waveform, sample_rate = librosa.load(audio_path, sr=None, mono=True)

    fig, ax = plt.subplots(figsize=(8, 3))
    librosa.display.waveshow(waveform, sr=sample_rate, ax=ax, color="#4C72B0")
    ax.set_title("Audio Waveform")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude")
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150)

    return fig


def plot_metrics_bar(metrics: dict, save_path: Optional[str] = None):
    """Plot a simple bar chart of key numeric metrics (e.g. accuracy,
    delivery score, pause ratio as %) for quick visual comparison.
    """
    labels = list(metrics.keys())
    values = list(metrics.values())

    fig, ax = plt.subplots(figsize=(6, 3.5))
    bars = ax.bar(labels, values, color="#55A868")
    ax.set_ylim(0, max(100, max(values) * 1.1 if values else 100))
    ax.set_ylabel("Score")
    ax.set_title("Evaluation Metrics")

    for bar, value in zip(bars, values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 1,
            f"{value:.1f}",
            ha="center",
            va="bottom",
            fontsize=9,
        )

    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150)

    return fig
