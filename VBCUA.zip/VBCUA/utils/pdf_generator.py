"""
pdf_generator.py
------------------
Builds a downloadable PDF evaluation report combining:
  - Session/concept metadata
  - Transcript
  - Evaluation metrics table
  - Waveform image
  - Feedback text

Two implementations are provided:
  - generate_report_weasyprint(): renders an HTML template and converts it
    to PDF with WeasyPrint. Preferred for richer styling.
  - generate_report_reportlab(): builds the PDF directly with ReportLab.
    Useful when WeasyPrint's system dependencies (Pango/Cairo) aren't
    available, e.g. some minimal container images.
"""

from __future__ import annotations

import datetime as dt
from typing import Optional


REPORT_CSS = """
body { font-family: Helvetica, Arial, sans-serif; color: #222; margin: 40px; }
h1 { color: #2c3e50; border-bottom: 2px solid #2c3e50; padding-bottom: 8px; }
h2 { color: #34495e; margin-top: 28px; }
table { border-collapse: collapse; width: 100%; margin-top: 10px; }
th, td { border: 1px solid #ccc; padding: 8px 12px; text-align: left; }
th { background-color: #f2f2f2; }
.feedback-box { background: #eef7ee; border-left: 4px solid #55A868; padding: 12px 16px; margin-top: 16px; }
.transcript-box { background: #f7f7f7; border-left: 4px solid #4C72B0; padding: 12px 16px; font-style: italic; }
img.waveform { width: 100%; margin-top: 16px; }
.footer { margin-top: 40px; font-size: 11px; color: #888; }
"""


def _build_html(
    student_name: str,
    concept_description: str,
    transcript: str,
    accuracy_score: float,
    understanding_label: str,
    filler_count: int,
    pause_ratio: float,
    delivery_score: float,
    feedback: str,
    waveform_image_path: Optional[str] = None,
) -> str:
    waveform_html = (
        f'<img class="waveform" src="{waveform_image_path}" alt="Waveform" />'
        if waveform_image_path
        else ""
    )

    return f"""
    <html>
    <head><meta charset="utf-8"><style>{REPORT_CSS}</style></head>
    <body>
        <h1>VBCUA Evaluation Report</h1>
        <p><strong>Student:</strong> {student_name} &nbsp;|&nbsp;
           <strong>Date:</strong> {dt.datetime.now().strftime('%Y-%m-%d %H:%M')}</p>

        <h2>Concept</h2>
        <p>{concept_description}</p>

        <h2>Transcript</h2>
        <div class="transcript-box">{transcript or '(no transcript available)'}</div>

        <h2>Evaluation Metrics</h2>
        <table>
            <tr><th>Metric</th><th>Value</th></tr>
            <tr><td>Semantic Accuracy</td><td>{accuracy_score:.2f}</td></tr>
            <tr><td>Understanding Level</td><td>{understanding_label}</td></tr>
            <tr><td>Filler Word Count</td><td>{filler_count}</td></tr>
            <tr><td>Pause Ratio</td><td>{pause_ratio:.1%}</td></tr>
            <tr><td>Delivery Score</td><td>{delivery_score:.1f} / 100</td></tr>
        </table>

        {waveform_html}

        <h2>Feedback</h2>
        <div class="feedback-box">{feedback}</div>

        <div class="footer">Generated automatically by VBCUA. This report is
        intended to assist, not replace, instructor judgment.</div>
    </body>
    </html>
    """


def generate_report_weasyprint(output_path: str, **kwargs) -> str:
    """Render the HTML report and convert it to PDF using WeasyPrint."""
    from weasyprint import HTML

    html_content = _build_html(**kwargs)
    HTML(string=html_content).write_pdf(output_path)
    return output_path


def generate_report_reportlab(output_path: str, **kwargs) -> str:
    """Build the PDF directly with ReportLab (no external system deps)."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
        Table,
        TableStyle,
        Image,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleStyle", parent=styles["Title"], textColor=colors.HexColor("#2c3e50"))
    heading_style = ParagraphStyle("HeadingStyle", parent=styles["Heading2"], textColor=colors.HexColor("#34495e"))
    body_style = styles["BodyText"]

    doc = SimpleDocTemplate(output_path, pagesize=letter)
    story = []

    story.append(Paragraph("VBCUA Evaluation Report", title_style))
    story.append(Spacer(1, 12))
    story.append(
        Paragraph(
            f"Student: {kwargs.get('student_name', 'N/A')} | "
            f"Date: {dt.datetime.now().strftime('%Y-%m-%d %H:%M')}",
            body_style,
        )
    )

    story.append(Spacer(1, 12))
    story.append(Paragraph("Concept", heading_style))
    story.append(Paragraph(kwargs.get("concept_description", ""), body_style))

    story.append(Spacer(1, 12))
    story.append(Paragraph("Transcript", heading_style))
    story.append(Paragraph(kwargs.get("transcript") or "(no transcript available)", body_style))

    story.append(Spacer(1, 12))
    story.append(Paragraph("Evaluation Metrics", heading_style))
    table_data = [
        ["Metric", "Value"],
        ["Semantic Accuracy", f"{kwargs.get('accuracy_score', 0):.2f}"],
        ["Understanding Level", kwargs.get("understanding_label", "N/A")],
        ["Filler Word Count", str(kwargs.get("filler_count", 0))],
        ["Pause Ratio", f"{kwargs.get('pause_ratio', 0):.1%}"],
        ["Delivery Score", f"{kwargs.get('delivery_score', 0):.1f} / 100"],
    ]
    table = Table(table_data, colWidths=[200, 200])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f2f2f2")),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    story.append(table)

    waveform_image_path = kwargs.get("waveform_image_path")
    if waveform_image_path:
        story.append(Spacer(1, 16))
        story.append(Image(waveform_image_path, width=450, height=170))

    story.append(Spacer(1, 12))
    story.append(Paragraph("Feedback", heading_style))
    story.append(Paragraph(kwargs.get("feedback", ""), body_style))

    doc.build(story)
    return output_path


def generate_report(output_path: str, engine: str = "weasyprint", **kwargs) -> str:
    """Generate the PDF report, choosing the backend engine.

    Falls back to ReportLab automatically if WeasyPrint isn't available
    (e.g. missing system libraries like Pango/Cairo).
    """
    if engine == "weasyprint":
        try:
            return generate_report_weasyprint(output_path, **kwargs)
        except ImportError:
            return generate_report_reportlab(output_path, **kwargs)
    return generate_report_reportlab(output_path, **kwargs)
